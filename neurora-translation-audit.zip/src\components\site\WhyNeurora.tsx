import { ShieldCheck, Clock, FileCheck, Network, Sparkles } from "lucide-react";

const reasons = [
  { icon: ShieldCheck, title: "Hassle-Free Ownership", desc: "We take everything off your plate." },
  { icon: Clock, title: "Reliable & Responsive", desc: "Swift action whenever it matters." },
  { icon: FileCheck, title: "Transparent Expenses", desc: "Clear records, no surprises." },
  { icon: Network, title: "Trusted Network", desc: "Vetted professionals only." },
  { icon: Sparkles, title: "Attention to Detail", desc: "Care is in every interaction." },
];

const WhyNeurora = () => {
  return (
    <section id="why" className="py-24 lg:py-32 bg-gradient-soft">
      <div className="container-narrow">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-[0.25em] uppercase text-accent mb-4 block">
            Why Neurora
          </span>
          <h2 className="font-display text-4xl lg:text-5xl text-foreground leading-tight text-balance mb-6">
            A standard of care reserved for properties that matter.
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Owners trust Neurora because every detail is managed with discretion,
            precision, and genuine accountability.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
          {reasons.map((r) => (
            <div
              key={r.title}
              className="bg-card border border-border rounded-xl p-7 text-center hover:shadow-soft hover:border-accent/40 transition-smooth"
            >
              <div className="h-14 w-14 mx-auto rounded-full bg-accent-soft flex items-center justify-center mb-5">
                <r.icon className="h-6 w-6 text-accent" />
              </div>
              <h3 className="font-display text-lg text-foreground mb-2">
                {r.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {r.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyNeurora;
