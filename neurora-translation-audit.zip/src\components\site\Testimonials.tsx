import { Quote } from "lucide-react";

const testimonials = [
  {
    quote:
      "Neurora has completely transformed how I manage my property from abroad. Everything is handled, and I never have to worry. They truly care.",
    name: "Daniel R.",
    role: "Overseas Property Owner",
  },
  {
    quote:
      "Professional, responsive, and meticulous. Bills, repairs, and contractors all coordinated seamlessly. The peace of mind is genuinely priceless.",
    name: "Elena M.",
    role: "Private Investor",
  },
  {
    quote:
      "Reliability you can feel. Reports are clear, the team is trustworthy, and my property is always in immaculate condition.",
    name: "James T.",
    role: "Residential Owner",
  },
];

const Testimonials = () => {
  return (
    <section className="py-24 lg:py-32 bg-secondary/40">
      <div className="container-narrow">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-bold tracking-[0.25em] uppercase text-accent mb-4 block">
            Testimonials
          </span>
          <h2 className="font-display text-4xl lg:text-5xl text-foreground leading-tight text-balance">
            Trusted by owners who expect more.
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t) => (
            <figure
              key={t.name}
              className="bg-card border border-border rounded-xl p-8 flex flex-col shadow-card hover:shadow-elegant transition-smooth"
            >
              <Quote className="h-8 w-8 text-accent mb-6" />
              <blockquote className="text-foreground/90 leading-relaxed mb-8 flex-1">
                "{t.quote}"
              </blockquote>
              <figcaption className="border-t border-border pt-5">
                <div className="font-display text-lg text-foreground">
                  {t.name}
                </div>
                <div className="text-xs tracking-wider uppercase text-muted-foreground mt-1">
                  {t.role}
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
